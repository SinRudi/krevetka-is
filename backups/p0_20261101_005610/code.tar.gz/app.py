from flask import Flask, render_template, request, jsonify, g, session, redirect, url_for, flash, make_response, send_from_directory, send_file, abort
from datetime import datetime, timedelta
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import os
import re
import uuid
import io
import openpyxl
import time

app = Flask(__name__)
app.secret_key = os.environ.get('SUSHI_SECRET', 'super-secret-key-change-me')
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sushi.db')
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static', 'uploads')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'webp', 'gif'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

typing_users = {}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(DB_PATH, timeout=10)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
        g.db.execute("PRAGMA journal_mode = WAL")
        g.db.execute("PRAGMA busy_timeout = 5000")
    return g.db

@app.teardown_appcontext
def close_db(exception):
    db = g.pop('db', None)
    if db is not None:
        db.close()

@app.route('/manifest.json')
def manifest(): return send_from_directory(os.path.dirname(os.path.abspath(__file__)), 'manifest.json')
@app.route('/chat_manifest.json')
def chat_manifest(): return send_from_directory(os.path.dirname(os.path.abspath(__file__)), 'chat_manifest.json')
@app.route('/sw.js')
def service_worker(): return send_from_directory(os.path.dirname(os.path.abspath(__file__)), 'sw.js')

def get_setting(key):
    row = get_db().execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return row['value'] if row else None

def set_setting(key, value):
    db = get_db()
    db.execute("INSERT INTO settings (key, value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=?", (key, value, value))
    db.commit()

def is_shop_open():
    status = get_setting('shop_status') or 'auto'
    if status == 'closed': return False
    if status == 'open': return True
    b = get_brand_settings()
    try:
        t_start = datetime.strptime(b['work_start'], "%H:%M").time()
        t_end = datetime.strptime(b['work_end'], "%H:%M").time()
        now = datetime.now().time()
        return t_start <= now <= t_end
    except Exception:
        return True

def init_db():
    db = sqlite3.connect(DB_PATH)
    db.execute("PRAGMA journal_mode = WAL")
    db.executescript('''
    CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
    CREATE TABLE IF NOT EXISTS banners (id INTEGER PRIMARY KEY AUTOINCREMENT, image TEXT NOT NULL, title TEXT);
    CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY AUTOINCREMENT, sender_id INTEGER, sender_name TEXT, text TEXT, created_at TEXT, is_read INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS courier_locations (courier_id INTEGER PRIMARY KEY, lat REAL, lng REAL, updated_at TEXT);
    CREATE TABLE IF NOT EXISTS menu (
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, price INTEGER NOT NULL,
        category TEXT NOT NULL, available INTEGER NOT NULL DEFAULT 1, stop_list INTEGER DEFAULT 0,
        image TEXT DEFAULT '', composition TEXT DEFAULT '', modifiers TEXT DEFAULT '', sort_weight INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'new',
        total INTEGER NOT NULL, cost REAL DEFAULT 0, address TEXT, phone TEXT, comment TEXT, shift_id INTEGER,
        cashier_id INTEGER DEFAULT 0, source TEXT DEFAULT 'Касса',
        payment_method TEXT DEFAULT 'не указан', payment_cash INTEGER DEFAULT 0, payment_card INTEGER DEFAULT 0, change_from INTEGER DEFAULT 0,
        delivery_type TEXT DEFAULT 'доставка', scheduled_time TEXT,
        cancel_reason TEXT DEFAULT '', courier_name TEXT DEFAULT '', discount INTEGER DEFAULT 0,
        discount_type TEXT DEFAULT 'rub', delivery_zone TEXT DEFAULT '', delivery_price INTEGER DEFAULT 0,
        used_bonus INTEGER DEFAULT 0, cook_start_time TEXT, cook_end_time TEXT, promo_code TEXT DEFAULT '', rating INTEGER DEFAULT 0, review_text TEXT DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS order_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL, menu_id INTEGER,
        name TEXT NOT NULL, price INTEGER NOT NULL, qty INTEGER NOT NULL DEFAULT 1, modifiers TEXT DEFAULT '',
        FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'cashier', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS shifts (
        id INTEGER PRIMARY KEY AUTOINCREMENT, opened_at TEXT NOT NULL, closed_at TEXT,
        opened_by INTEGER, closed_by INTEGER, total_orders INTEGER DEFAULT 0,
        total_revenue INTEGER DEFAULT 0, status TEXT NOT NULL DEFAULT 'open', total_cash INTEGER DEFAULT 0, total_card INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS clients (id INTEGER PRIMARY KEY AUTOINCREMENT, phone TEXT UNIQUE NOT NULL, name TEXT, bonuses INTEGER DEFAULT 0, total_spent INTEGER DEFAULT 0, orders_count INTEGER DEFAULT 0, last_order_at TEXT, level TEXT DEFAULT 'bronze');
    CREATE TABLE IF NOT EXISTS zones (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, price INTEGER NOT NULL, polygon_data TEXT DEFAULT '');
    CREATE TABLE IF NOT EXISTS cash_operations (
        id INTEGER PRIMARY KEY AUTOINCREMENT, shift_id INTEGER, op_type TEXT, amount INTEGER, comment TEXT, created_at TEXT, username TEXT
    );
    CREATE TABLE IF NOT EXISTS promocodes (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE NOT NULL, discount_type TEXT NOT NULL DEFAULT 'percent', discount_value INTEGER NOT NULL, is_active INTEGER DEFAULT 1);
    CREATE TABLE IF NOT EXISTS ingredients (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, stock REAL DEFAULT 0, unit TEXT NOT NULL, cost_price REAL DEFAULT 0, is_prep INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS recipes (menu_id INTEGER, ingredient_id INTEGER, amount REAL NOT NULL, PRIMARY KEY (menu_id, ingredient_id), FOREIGN KEY(menu_id) REFERENCES menu(id) ON DELETE CASCADE, FOREIGN KEY(ingredient_id) REFERENCES ingredients(id) ON DELETE CASCADE);
    CREATE TABLE IF NOT EXISTS stock_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL, ingredient_id INTEGER,
        ing_name TEXT, change_amount REAL, op_type TEXT, reason TEXT, cost_impact REAL DEFAULT 0, username TEXT
    );
    ''')
    for alter_sql in [
        "ALTER TABLE orders ADD COLUMN delivery_price INTEGER DEFAULT 0",
        "ALTER TABLE orders ADD COLUMN used_bonus INTEGER DEFAULT 0",
        "ALTER TABLE ingredients ADD COLUMN is_prep INTEGER DEFAULT 0"
    ]:
        try: db.execute(alter_sql)
        except Exception: pass

    if db.execute("SELECT COUNT(*) FROM settings").fetchone()[0] == 0:
        db.execute("INSERT INTO settings (key, value) VALUES ('shop_status', 'auto')")
    if db.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        db.executemany("INSERT INTO users (username, password_hash, role, created_at) VALUES (?,?,?,?)", [
            ("admin", generate_password_hash("admin"), "admin", now), ("cashier", generate_password_hash("cashier"), "cashier", now),
            ("kitchen", generate_password_hash("kitchen"), "kitchen", now), ("courier", generate_password_hash("courier"), "courier", now),
        ])
    if db.execute("SELECT COUNT(*) FROM promocodes").fetchone()[0] == 0:
        db.execute("INSERT INTO promocodes (code, discount_type, discount_value) VALUES (?,?,?)", ("SUSHI10", "percent", 10))
    db.commit()
    db.close()

def login_required(*roles):
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            if 'user_id' not in session: return redirect(url_for('login'))
            if roles and session.get('role') not in roles: return "Доступ запрещён", 403
            return f(*args, **kwargs)
        return wrapper
    return decorator

def parse_mods_extra_price(mods_str, menu_mods_str):
    if not mods_str or not menu_mods_str: return 0
    allowed = {}
    for part in menu_mods_str.split(','):
        if ':' in part:
            k, v = part.split(':', 1)
            try: allowed[k.strip().lower()] = int(v.strip())
            except ValueError: pass
    extra = 0
    for chosen in mods_str.split(','):
        c_name = chosen.split('(')[0].replace('+', '').strip().lower()
        if c_name in allowed: extra += allowed[c_name]
    return extra

def validate_and_prepare_items(raw_items, allow_stop_list=False):
    db = get_db()
    validated = []
    for i in raw_items:
        menu_id = i.get('id')
        qty = max(1, int(i.get('qty', 1)))
        row = db.execute("SELECT id, name, price, available, stop_list, modifiers FROM menu WHERE id=?", (menu_id,)).fetchone()
        if not row or not row['available']:
            return None, f"Блюдо '{i.get('name', 'Неизвестно')}' недоступно"
        if row['stop_list'] and not allow_stop_list:
            return None, f"Блюдо '{row['name']}' в стоп-листе"
        mods = str(i.get('mods', '')).strip()
        extra = parse_mods_extra_price(mods, row['modifiers'] or '')
        validated.append({
            "id": row['id'],
            "name": row['name'],
            "price": int(row['price']) + extra,
            "qty": qty,
            "mods": mods
        })
    return validated, None

def deduct_ingredients(items):
    db = get_db()
    total_cost = 0
    deductions = {}
    for i in items:
        qty = int(i.get('qty', 1))
        recipes = db.execute('''
            SELECT r.ingredient_id, r.amount, ing.name, ing.stock, ing.cost_price, COALESCE(ing.waste_pct, 0) as waste_pct
            FROM recipes r JOIN ingredients ing ON r.ingredient_id = ing.id 
            WHERE r.menu_id=?
        ''', (i.get('id'),)).fetchall()
        for r in recipes:
            ing_id = r['ingredient_id']
            waste = min(95.0, max(0.0, float(r['waste_pct'] or 0)))
            brutto_factor = 1.0 / (1.0 - waste / 100.0) if waste > 0 else 1.0
            needed_brutto = r['amount'] * qty * brutto_factor
            if ing_id not in deductions:
                deductions[ing_id] = {"needed": 0.0, "name": r['name'], "stock": r['stock'], "cost_price": r['cost_price']}
            deductions[ing_id]["needed"] += needed_brutto

    for ing_id, info in deductions.items():
        if info["stock"] < info["needed"]:
            return f"Не хватает на складе: {info['name']} (нужно с учетом отхода {round(info['needed'], 2)}, есть {round(info['stock'], 2)})", 0

    for ing_id, info in deductions.items():
        db.execute("UPDATE ingredients SET stock = ROUND(stock - ?, 4) WHERE id=?", (info["needed"], ing_id))
        total_cost += info["cost_price"] * info["needed"]

    return None, total_cost

def parse_zone_price(zone_str, delivery_type, client_level='bronze'):
    if delivery_type != 'доставка' or not zone_str or client_level == 'gold':
        return 0
    match = re.search(r'\((\d+)₽\)', zone_str)
    return int(match.group(1)) if match else 0

def split_payment_amounts(payment_method, total, raw_cash=0):
    if payment_method == 'наличные':
        return total, 0
    elif payment_method in ('карта', 'перевод'):
        return 0, total
    elif payment_method == 'микс':
        cash = min(total, max(0, int(raw_cash or 0)))
        return cash, max(0, total - cash)
    return 0, 0


import urllib.request
import urllib.parse
import json
import threading

DEFAULT_BRAND = {
    'brand_name': 'КРЕВЕТКА',
    'brand_slogan': 'Свежие морепродукты, пицца и роллы с доставкой',
    'brand_city': 'г. Инта',
    'brand_address': 'ул. Горького, 1',
    'brand_phone': '+7 (999) 000-00-00',
    'map_lat': '66.0350',
    'map_lng': '60.1450',
    'work_start': '10:00',
    'work_end': '21:30',
    'tg_token': '',
    'tg_chat_id': ''
}

def get_brand_settings():
    db = get_db()
    rows = db.execute("SELECT key, value FROM settings").fetchall()
    stored = {r['key']: r['value'] for r in rows}
    res = DEFAULT_BRAND.copy()
    for k in res:
        if k in stored and stored[k] is not None and stored[k] != '':
            res[k] = stored[k]
    return res

@app.context_processor
def inject_brand():
    try:
        return dict(brand=get_brand_settings())
    except Exception:
        return dict(brand=DEFAULT_BRAND)

def send_tg_async(text):
    try:
        b = get_brand_settings()
        token = b.get('tg_token', '').strip()
        chat_id = b.get('tg_chat_id', '').strip()
        if not token or not chat_id:
            return
        def _worker():
            try:
                url = f"https://api.telegram.org/bot{token}/sendMessage"
                data = urllib.parse.urlencode({'chat_id': chat_id, 'text': text, 'parse_mode': 'HTML'}).encode('utf-8')
                urllib.request.urlopen(url, data=data, timeout=5)
            except Exception:
                pass
        threading.Thread(target=_worker, daemon=True).start()
    except Exception:
        pass

@app.route('/admin/brand_settings', methods=['POST'])
@login_required('admin')
def admin_brand_settings():
    for k in DEFAULT_BRAND.keys():
        val = request.form.get(k, '').strip()
        set_setting(k, val)
    return redirect(url_for('admin_panel'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = get_db().execute("SELECT * FROM users WHERE username=?", (request.form.get('username', '').strip(),)).fetchone()
        if user and check_password_hash(user['password_hash'], request.form.get('password', '')):
            session.clear(); session['user_id'] = user['id']; session['username'] = user['username']; session['role'] = user['role']
            return redirect(url_for('index'))
        flash('Неверный логин или пароль')
    return render_template('login.html')

@app.route('/logout')
def logout(): session.clear(); return redirect(url_for('login'))

def get_open_shift(): return get_db().execute("SELECT * FROM shifts WHERE status='open' ORDER BY id DESC LIMIT 1").fetchone()

@app.route('/shift/open', methods=['POST'])
@login_required('admin', 'cashier')
def shift_open():
    if not get_open_shift():
        get_db().execute("INSERT INTO shifts (opened_at, opened_by, status) VALUES (?,?,?)", (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), session['user_id'], 'open'))
        get_db().commit()
    return redirect(url_for('index'))

@app.route('/shift/close', methods=['POST'])
@login_required('admin', 'cashier')
def shift_close():
    shift = get_open_shift()
    if not shift: return redirect(url_for('index'))
    db = get_db()
    row = db.execute("SELECT COUNT(*) cnt, COALESCE(SUM(total),0) rev, COALESCE(SUM(payment_cash),0) cash, COALESCE(SUM(payment_card),0) card FROM orders WHERE shift_id=? AND status!='cancelled'", (shift['id'],)).fetchone()
    db.execute("UPDATE shifts SET closed_at=?, closed_by=?, status='closed', total_orders=?, total_revenue=?, total_cash=?, total_card=? WHERE id=?", (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), session['user_id'], row['cnt'], row['rev'], row['cash'], row['card'], shift['id']))
    db.commit()
    send_tg_async(f"📊 <b>СМЕНА #{shift['id']} ЗАКРЫТА (Z-Отчет)</b>\n📦 Заказов: {row['cnt']}\n💰 Выручка: <b>{row['rev']} ₽</b>\n💵 Наличные: {row['cash']} ₽\n💳 Карта: {row['card']} ₽")
    return redirect(url_for('reports'))

@app.route('/')
@login_required()
def index():
    if session['role'] == 'kitchen': return redirect(url_for('kitchen'))
    if session['role'] == 'courier': return redirect(url_for('courier'))
    db = get_db()
    return render_template('cashier.html', menu=db.execute("SELECT * FROM menu WHERE available=1 ORDER BY sort_weight DESC, category, name").fetchall(), categories=db.execute("SELECT DISTINCT category FROM menu WHERE available=1 ORDER BY category").fetchall(), zones=db.execute("SELECT * FROM zones").fetchall(), shift=get_open_shift(), role=session['role'], shop_open=is_shop_open())

@app.route('/kitchen')
@login_required('admin', 'kitchen')
def kitchen(): return render_template('kitchen.html')

@app.route('/courier')
@login_required('admin', 'courier')
def courier(): return render_template('courier.html')

@app.route('/reports')
@login_required('admin', 'cashier')
def reports(): return render_template('reports.html', shifts=get_db().execute("SELECT * FROM shifts ORDER BY id DESC LIMIT 30").fetchall())

@app.route('/orders')
@login_required('admin', 'cashier')
def orders_view():
    db = get_db()
    return render_template('orders.html', users=db.execute("SELECT id, username FROM users").fetchall(), menu=db.execute("SELECT * FROM menu WHERE available=1 ORDER BY category, name").fetchall())

@app.route('/receipt/<int:order_id>')
@login_required()
def receipt(order_id):
    db = get_db()
    order = db.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
    if not order: return "Заказ не найден", 404
    items = db.execute("SELECT * FROM order_items WHERE order_id=?", (order_id,)).fetchall()
    return render_template('receipt.html', order=order, items=items, host_url=request.host_url)

@app.route('/ticket/<int:order_id>')
@login_required()
def ticket(order_id):
    db = get_db()
    order = db.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
    if not order: return "Заказ не найден", 404
    items = db.execute("SELECT * FROM order_items WHERE order_id=?", (order_id,)).fetchall()
    return render_template('ticket.html', order=order, items=items)

@app.route('/api/order/update_items/<int:order_id>', methods=['POST'])
@login_required('admin', 'cashier')
def update_order_items(order_id):
    data = request.json or {}
    raw_items = data.get('items', [])
    if not raw_items: return jsonify({"error": "В заказе должна остаться хотя бы одна позиция"}), 400
    db = get_db()
    order = db.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
    if not order or order['status'] in ('done', 'cancelled'):
        return jsonify({"error": "Нельзя редактировать закрытый заказ"}), 400

    validated_items, val_err = validate_and_prepare_items(raw_items, allow_stop_list=True)
    if val_err: return jsonify({"error": val_err}), 400

    old_items = db.execute("SELECT menu_id, qty FROM order_items WHERE order_id=?", (order_id,)).fetchall()
    for oi in old_items:
        if oi['menu_id']:
            for r in db.execute("SELECT ingredient_id, amount FROM recipes WHERE menu_id=?", (oi['menu_id'],)).fetchall():
                db.execute("UPDATE ingredients SET stock = ROUND(stock + ?, 4) WHERE id=?", (r['amount'] * oi['qty'], r['ingredient_id']))

    err, new_cost = deduct_ingredients(validated_items)
    if err:
        db.rollback()
        return jsonify({"error": err}), 400

    db.execute("DELETE FROM order_items WHERE order_id=?", (order_id,))
    subtotal = 0
    for i in validated_items:
        subtotal += i['price'] * i['qty']
        db.execute("INSERT INTO order_items (order_id, menu_id, name, price, qty, modifiers) VALUES (?,?,?,?,?,?)",
                   (order_id, i['id'], i['name'], i['price'], i['qty'], i['mods']))

    manual_discount = (subtotal * order['discount'] // 100) if order['discount_type'] == 'percent' else order['discount']
    promo_discount = 0
    if order['promo_code']:
        promo = db.execute("SELECT * FROM promocodes WHERE code=?", (order['promo_code'],)).fetchone()
        if promo:
            promo_discount = (subtotal * promo['discount_value']) // 100 if promo['discount_type'] == 'percent' else promo['discount_value']

    ord_dict = dict(order)
    delivery_price = ord_dict.get('delivery_price') or 0
    used_bonus = ord_dict.get('used_bonus') or 0
    new_total = max(0, subtotal - manual_discount - promo_discount - used_bonus) + delivery_price
    pay_cash, pay_card = split_payment_amounts(order['payment_method'], new_total, order['payment_cash'])

    db.execute("UPDATE orders SET total=?, cost=?, payment_cash=?, payment_card=? WHERE id=?",
               (new_total, new_cost, pay_cash, pay_card, order_id))
    db.commit()
    return jsonify({"success": True, "new_total": new_total})

@app.route('/api/all_orders')
@login_required()
def api_all_orders():
    db = get_db()
    date_filter = request.args.get('date', datetime.now().strftime("%Y-%m-%d"))
    cashier_id = request.args.get('cashier_id'); source = request.args.get('source'); status = request.args.get('status')
    query = "SELECT o.*, u.username as cashier_name FROM orders o LEFT JOIN users u ON o.cashier_id = u.id WHERE 1=1"
    params = []
    if date_filter: query += " AND date(o.created_at) = ?"; params.append(date_filter)
    if cashier_id: query += " AND o.cashier_id = ?"; params.append(cashier_id)
    if source: query += " AND o.source = ?"; params.append(source)
    if status: query += " AND o.status = ?"; params.append(status)
    query += " ORDER BY o.id DESC"
    rows = db.execute(query, params).fetchall()
    result = []; total_sum = 0
    for r in rows:
        order = dict(r); order['items'] = [dict(i) for i in db.execute("SELECT * FROM order_items WHERE order_id=?", (r['id'],)).fetchall()]; result.append(order)
        if order['status'] != 'cancelled': total_sum += order['total']
    valid_count = len([o for o in result if o['status'] != 'cancelled'])
    return jsonify({"orders": result, "stats": {"count": valid_count, "total": total_sum, "avg": round(total_sum / valid_count) if valid_count > 0 else 0}})

@app.route('/map')
@login_required('admin', 'cashier')
def map_view(): return render_template('map.html')

@app.route('/api/zones', methods=['GET', 'POST'])
@login_required('admin')
def api_zones():
    db = get_db()
    if request.method == 'POST':
        data = request.json
        db.execute("INSERT INTO zones (name, price, polygon_data) VALUES (?,?,?)", (data['name'], int(data['price']), data['polygon_data'])); db.commit()
        return jsonify({"success": True})
    return jsonify([dict(z) for z in db.execute("SELECT * FROM zones").fetchall()])

@app.route('/api/zones/delete/<int:zone_id>', methods=['POST'])
@login_required('admin')
def api_zones_delete(zone_id):
    db = get_db(); db.execute("DELETE FROM zones WHERE id=?", (zone_id,)); db.commit(); return jsonify({"success": True})

@app.route('/api/courier/location', methods=['POST'])
@login_required('courier', 'admin')
def api_courier_location():
    data = request.json or {}; lat, lng = data.get('lat'), data.get('lng')
    if lat and lng:
        db = get_db(); now_time = datetime.now().strftime("%H:%M:%S")
        db.execute("INSERT INTO courier_locations (courier_id, lat, lng, updated_at) VALUES (?,?,?,?) ON CONFLICT(courier_id) DO UPDATE SET lat=?, lng=?, updated_at=?", (session['user_id'], lat, lng, now_time, lat, lng, now_time))
        db.commit()
    return jsonify({"success": True})

@app.route('/api/couriers/locations')
@login_required('admin')
def api_couriers_locations():
    return jsonify([dict(r) for r in get_db().execute("SELECT c.lat, c.lng, c.updated_at, u.username FROM courier_locations c JOIN users u ON c.courier_id = u.id").fetchall()])

@app.route('/chat')
@login_required()
def chat_view(): return render_template('chat.html')

@app.route('/api/chat/get')
@login_required()
def api_chat_get():
    db = get_db()
    if db.execute("SELECT COUNT(*) FROM messages WHERE is_read=0 AND sender_id != ?", (session['user_id'],)).fetchone()[0] > 0:
        db.execute("UPDATE messages SET is_read=1 WHERE is_read=0 AND sender_id != ?", (session['user_id'],)); db.commit()
    msgs = db.execute("SELECT * FROM messages ORDER BY id DESC LIMIT 50").fetchall()
    now = time.time(); currently_typing = [u for u, t in typing_users.items() if now - t < 3 and u != session['username']]
    return jsonify({"messages": [dict(m) for m in reversed(msgs)], "typing": currently_typing})

@app.route('/api/chat/send', methods=['POST'])
@login_required()
def api_chat_send():
    data = request.json or {}; text = data.get('text', '').strip()
    if text:
        db = get_db(); db.execute("INSERT INTO messages (sender_id, sender_name, text, created_at, is_read) VALUES (?,?,?,?,0)", (session['user_id'], session['username'], text, datetime.now().strftime("%H:%M"))); db.commit()
        typing_users.pop(session['username'], None)
    return jsonify({"success": True})

@app.route('/api/chat/typing', methods=['POST'])
@login_required()
def api_chat_typing():
    typing_users[session['username']] = time.time(); return jsonify({"success": True})

@app.route('/api/chat/clear', methods=['POST'])
@login_required('admin')
def api_chat_clear():
    db = get_db(); db.execute("DELETE FROM messages"); db.commit(); return jsonify({"success": True})

@app.route('/crm')
@login_required('admin')
def crm_panel(): return render_template('crm.html', clients=get_db().execute("SELECT * FROM clients ORDER BY total_spent DESC").fetchall())

def recalc_prep_cost(db, prep_id):
    prep = db.execute("SELECT * FROM ingredients WHERE id=?", (prep_id,)).fetchone()
    if not prep: return
    rows = db.execute('''
        SELECT pr.amount, ing.cost_price, COALESCE(ing.waste_pct, 0) as waste_pct
        FROM prep_recipes pr JOIN ingredients ing ON pr.raw_id = ing.id
        WHERE pr.prep_id=?
    ''', (prep_id,)).fetchall()
    if not rows: return
    batch_cost = 0.0
    raw_sum = 0.0
    for r in rows:
        w = min(95.0, max(0.0, float(r['waste_pct'] or 0)))
        factor = 1.0 / (1.0 - w / 100.0) if w > 0 else 1.0
        batch_cost += (r['amount'] * factor) * r['cost_price']
        raw_sum += r['amount']
    yield_amt = float(prep['prep_yield'] or 0)
    if yield_amt <= 0:
        yield_amt = raw_sum if raw_sum > 0 else 1.0
    unit_cost = round(batch_cost / yield_amt, 4)
    db.execute("UPDATE ingredients SET cost_price=?, prep_yield=? WHERE id=?", (unit_cost, yield_amt, prep_id))

@app.route('/warehouse')
@login_required('admin')
def warehouse_panel():
    db = get_db()
    ings = db.execute("SELECT * FROM ingredients ORDER BY is_prep DESC, name").fetchall()
    preps = [dict(i) for i in ings if i['is_prep']]
    raw_ings = [dict(i) for i in ings if not i['is_prep']]
    for p in preps:
        p['recipe'] = [dict(r) for r in db.execute('''
            SELECT pr.raw_id, pr.amount, ing.name, ing.unit, ing.cost_price, COALESCE(ing.waste_pct, 0) as waste_pct
            FROM prep_recipes pr JOIN ingredients ing ON pr.raw_id = ing.id
            WHERE pr.prep_id=?
        ''', (p['id'],)).fetchall()]
        p['raw_weight'] = round(sum(r['amount'] for r in p['recipe']), 3)
    logs = db.execute("SELECT * FROM stock_logs ORDER BY id DESC LIMIT 60").fetchall()
    total_stock_value = sum(max(0, i['stock']) * i['cost_price'] for i in ings)
    return render_template('warehouse.html', ingredients=ings, preps=preps, raw_ings=raw_ings, logs=logs, total_stock_value=round(total_stock_value, 1))

@app.route('/admin/ingredient/add', methods=['POST'])
@login_required('admin')
def admin_ingredient_add():
    if request.form.get('name') and request.form.get('unit'):
        db = get_db()
        name = request.form.get('name').strip()
        stock = float(request.form.get('stock') or 0)
        unit = request.form.get('unit').strip()
        cost = float(request.form.get('cost_price') or 0)
        waste = min(95.0, max(0.0, float(request.form.get('waste_pct') or 0)))
        is_prep = 1 if request.form.get('is_prep') else 0
        cur = db.execute("INSERT INTO ingredients (name, stock, unit, cost_price, is_prep, waste_pct, prep_yield) VALUES (?,?,?,?,?,?,?)",
                         (name, stock, unit, cost, is_prep, waste, 1000.0 if is_prep else 0))
        if stock > 0:
            db.execute("INSERT INTO stock_logs (created_at, ingredient_id, ing_name, change_amount, op_type, reason, cost_impact, username) VALUES (?,?,?,?,?,?,?,?)",
                       (datetime.now().strftime("%Y-%m-%d %H:%M"), cur.lastrowid, name, stock, 'приход', 'Начальный остаток', round(stock * cost, 1), session['username']))
        db.commit()
    return redirect(url_for('warehouse_panel'))

@app.route('/admin/ingredient/update/<int:ing_id>', methods=['POST'])
@login_required('admin')
def admin_ingredient_update(ing_id):
    db = get_db()
    ing = db.execute("SELECT * FROM ingredients WHERE id=?", (ing_id,)).fetchone()
    if not ing: return redirect(url_for('warehouse_panel'))
    action = request.form.get('action')
    val = float(request.form.get('val') or 0)
    cost = float(request.form.get('cost_price', ing['cost_price']) or 0)
    waste = min(95.0, max(0.0, float(request.form.get('waste_pct', ing['waste_pct'] or 0) or 0)))
    reason = request.form.get('reason', '').strip()
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M")

    if action == 'settings':
        db.execute("UPDATE ingredients SET cost_price=?, waste_pct=? WHERE id=?", (cost, waste, ing_id))
    elif action == 'add' and val > 0:
        db.execute("UPDATE ingredients SET stock = ROUND(stock + ?, 4), cost_price = ?, waste_pct = ? WHERE id=?", (val, cost, waste, ing_id))
        db.execute("INSERT INTO stock_logs (created_at, ingredient_id, ing_name, change_amount, op_type, reason, cost_impact, username) VALUES (?,?,?,?,?,?,?,?)",
                   (now_str, ing_id, ing['name'], val, 'приход', reason or 'Поставка товара', round(val * cost, 1), session['username']))
    elif action == 'writeoff' and val > 0:
        diff = -abs(val)
        db.execute("UPDATE ingredients SET stock = ROUND(stock + ?, 4) WHERE id=?", (diff, ing_id))
        db.execute("INSERT INTO stock_logs (created_at, ingredient_id, ing_name, change_amount, op_type, reason, cost_impact, username) VALUES (?,?,?,?,?,?,?,?)",
                   (now_str, ing_id, ing['name'], diff, 'списание', reason or 'Списание (Стафф/Порча)', round(diff * cost, 1), session['username']))
    for p in db.execute("SELECT DISTINCT prep_id FROM prep_recipes WHERE raw_id=?", (ing_id,)).fetchall():
        recalc_prep_cost(db, p['prep_id'])
    db.commit()
    return redirect(url_for('warehouse_panel'))

@app.route('/admin/prep/save/<int:prep_id>', methods=['POST'])
@login_required('admin')
def admin_prep_save(prep_id):
    db = get_db()
    prep_yield = float(request.form.get('prep_yield') or 1)
    db.execute("UPDATE ingredients SET prep_yield=? WHERE id=?", (prep_yield, prep_id))
    db.execute("DELETE FROM prep_recipes WHERE prep_id=?", (prep_id,))
    for k, v in request.form.items():
        if k.startswith('raw_') and v.strip():
            amt = float(v)
            if amt > 0:
                raw_id = int(k.split('_')[1])
                db.execute("INSERT INTO prep_recipes (prep_id, raw_id, amount) VALUES (?,?,?)", (prep_id, raw_id, amt))
    recalc_prep_cost(db, prep_id)
    db.commit()
    return redirect(url_for('warehouse_panel') + '#tab-preps')

@app.route('/admin/prep/produce/<int:prep_id>', methods=['POST'])
@login_required('admin')
def admin_prep_produce(prep_id):
    db = get_db()
    prep = db.execute("SELECT * FROM ingredients WHERE id=?", (prep_id,)).fetchone()
    if not prep: return redirect(url_for('warehouse_panel'))
    batches = float(request.form.get('batches') or 1.0)
    recipe = db.execute('''
        SELECT pr.raw_id, pr.amount, ing.name, ing.unit, ing.cost_price, COALESCE(ing.waste_pct, 0) as waste_pct
        FROM prep_recipes pr JOIN ingredients ing ON pr.raw_id = ing.id
        WHERE pr.prep_id=?
    ''', (prep_id,)).fetchall()
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M")
    for r in recipe:
        w = min(95.0, max(0.0, float(r['waste_pct'] or 0)))
        factor = 1.0 / (1.0 - w / 100.0) if w > 0 else 1.0
        spend_brutto = round(r['amount'] * batches * factor, 4)
        db.execute("UPDATE ingredients SET stock = ROUND(stock - ?, 4) WHERE id=?", (spend_brutto, r['raw_id']))
        db.execute("INSERT INTO stock_logs (created_at, ingredient_id, ing_name, change_amount, op_type, reason, cost_impact, username) VALUES (?,?,?,?,?,?,?,?)",
                   (now_str, r['raw_id'], r['name'], -spend_brutto, 'в заготовку', f"На П/Ф: {prep['name']} (x{batches})", -round(spend_brutto * r['cost_price'], 1), session['username']))
    recalc_prep_cost(db, prep_id)
    prep = db.execute("SELECT * FROM ingredients WHERE id=?", (prep_id,)).fetchone()
    out_weight = round(float(prep['prep_yield'] or 1) * batches, 4)
    db.execute("UPDATE ingredients SET stock = ROUND(stock + ?, 4) WHERE id=?", (out_weight, prep_id))
    db.execute("INSERT INTO stock_logs (created_at, ingredient_id, ing_name, change_amount, op_type, reason, cost_impact, username) VALUES (?,?,?,?,?,?,?,?)",
               (now_str, prep_id, prep['name'], out_weight, 'варка П/Ф', f"Приготовлено партий: {batches}", round(out_weight * prep['cost_price'], 1), session['username']))
    db.commit()
    return redirect(url_for('warehouse_panel') + '#tab-preps')

@app.route('/admin/warehouse/inventory', methods=['POST'])
@login_required('admin')
def admin_warehouse_inventory():
    db = get_db()
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M")
    decompose = request.form.get('decompose_preps') == '1'
    ings = {i['id']: dict(i) for i in db.execute("SELECT * FROM ingredients").fetchall()}
    extra_raw_from_preps = {}

    if decompose:
        for pid, p in ings.items():
            if p['is_prep']:
                val_str = request.form.get(f"fact_{pid}", "").strip()
                if val_str != "":
                    try:
                        fact_prep = float(val_str)
                        yield_amt = float(p['prep_yield'] or 1)
                        if fact_prep > 0 and yield_amt > 0:
                            ratio = fact_prep / yield_amt
                            for r in db.execute("SELECT raw_id, amount FROM prep_recipes WHERE prep_id=?", (pid,)).fetchall():
                                raw_ing = ings.get(r['raw_id'])
                                w = min(95.0, max(0.0, float(raw_ing['waste_pct'] or 0))) if raw_ing else 0
                                factor = 1.0 / (1.0 - w / 100.0) if w > 0 else 1.0
                                extra_raw_from_preps[r['raw_id']] = extra_raw_from_preps.get(r['raw_id'], 0.0) + (r['amount'] * ratio * factor)
                    except Exception:
                        pass

    for ing_id, ing in ings.items():
        if decompose and ing['is_prep']:
            continue
        field_val = request.form.get(f"fact_{ing_id}", "").strip()
        if field_val != "":
            try:
                fact = float(field_val) + extra_raw_from_preps.get(ing_id, 0.0)
                diff = round(fact - ing['stock'], 4)
                if abs(diff) > 0.0001:
                    note = f"Было: {round(ing['stock'],3)}, Факт: {round(fact,3)}"
                    if ing_id in extra_raw_from_preps:
                        note += f" (вкл. +{round(extra_raw_from_preps[ing_id],2)} из П/Ф)"
                    db.execute("UPDATE ingredients SET stock = ? WHERE id=?", (round(fact, 4), ing_id))
                    db.execute("INSERT INTO stock_logs (created_at, ingredient_id, ing_name, change_amount, op_type, reason, cost_impact, username) VALUES (?,?,?,?,?,?,?,?)",
                               (now_str, ing_id, ing['name'], diff, 'ревизия', note, round(diff * ing['cost_price'], 1), session['username']))
            except Exception:
                pass
    db.commit()
    return redirect(url_for('warehouse_panel') + '#tab-logs')

@app.route('/admin/ingredient/delete/<int:ing_id>', methods=['POST'])
@login_required('admin')
def admin_ingredient_delete(ing_id):
    db = get_db(); db.execute("DELETE FROM ingredients WHERE id=?", (ing_id,)); db.commit(); return redirect(url_for('warehouse_panel'))

@app.route('/analytics')
@login_required('admin')
def analytics_panel():
    db = get_db(); stats = db.execute("SELECT SUM(total) as rev, SUM(cost) as cost FROM orders WHERE status != 'cancelled'").fetchone()
    total_rev = stats['rev'] or 0; total_cost = stats['cost'] or 0; total_profit = total_rev - total_cost
    return render_template('analytics.html', total_rev=total_rev, total_cost=total_cost, total_profit=total_profit, margin=round((total_profit / total_rev * 100) if total_rev > 0 else 0, 1), recent_orders=db.execute("SELECT * FROM orders ORDER BY id DESC LIMIT 10").fetchall())

@app.route('/track/<int:order_id>')
def track_order(order_id): return render_template('track.html', order_id=order_id)

@app.route('/api/track_order/<int:order_id>')
def api_track_order(order_id):
    order = get_db().execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
    if not order: return jsonify({"error": "Not found"}), 404
    return jsonify({"status": order['status'], "total": order['total'], "created_at": order['created_at']})

@app.route('/admin/shop_status', methods=['POST'])
@login_required('admin')
def admin_shop_status():
    if request.form.get('status') in ['auto', 'open', 'closed']: set_setting('shop_status', request.form.get('status'))
    return redirect(url_for('admin_panel'))

@app.route('/admin/banner/add', methods=['POST'])
@login_required('admin')
def admin_banner_add():
    file = request.files.get('image')
    if file and file.filename and allowed_file(file.filename):
        filename = 'banner_' + str(uuid.uuid4()) + '.' + file.filename.rsplit('.', 1)[1].lower(); file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        db = get_db(); db.execute("INSERT INTO banners (image, title) VALUES (?,?)", (filename, request.form.get('title', ''))); db.commit()
    return redirect(url_for('admin_panel'))

@app.route('/admin/banner/delete/<int:b_id>', methods=['POST'])
@login_required('admin')
def admin_banner_delete(b_id):
    db = get_db(); db.execute("DELETE FROM banners WHERE id=?", (b_id,)); db.commit(); return redirect(url_for('admin_panel'))

@app.route('/admin/backup_db')
@login_required('admin')
def backup_db(): return send_file(DB_PATH, as_attachment=True, download_name=f"sushi_backup_{datetime.now().strftime('%Y%m%d_%H%M')}.db")

@app.route('/admin')
@login_required('admin')
def admin_panel():
    db = get_db(); today = datetime.now().strftime("%Y-%m-%d")
    stats = db.execute("SELECT COUNT(*) cnt, COALESCE(SUM(total), 0) rev FROM orders WHERE date(created_at) = ? AND status != 'cancelled'", (today,)).fetchone()
    avg_check = (stats['rev'] / stats['cnt']) if stats['cnt'] > 0 else 0
    rating_row = db.execute("SELECT AVG(rating) as avg_r, COUNT(rating) as count_r FROM orders WHERE rating > 0").fetchone()
    avg_rating = round(rating_row['avg_r'], 1) if rating_row['avg_r'] else 0; reviews_count = rating_row['count_r']
    chart_data = []
    for i in range(6, -1, -1):
        d = (datetime.now() - timedelta(days=i)).strftime("%Y-%m-%d")
        r = db.execute("SELECT COALESCE(SUM(total),0) rev FROM orders WHERE date(created_at)=? AND status!='cancelled'", (d,)).fetchone()
        chart_data.append({"date": d[5:], "rev": r['rev']})
    top_items = db.execute("SELECT oi.name, SUM(oi.qty) total_qty FROM order_items oi JOIN orders o ON oi.order_id = o.id WHERE date(o.created_at) = ? AND o.status != 'cancelled' GROUP BY oi.name ORDER BY total_qty DESC LIMIT 5", (today,)).fetchall()
    top_clients = db.execute("SELECT phone, COUNT(*) cnt, SUM(total) sum FROM orders WHERE date(created_at) = ? AND status != 'cancelled' AND phone != '' GROUP BY phone ORDER BY sum DESC LIMIT 5", (today,)).fetchall()
    return render_template('admin.html', stats=stats, avg_check=avg_check, chart_data=chart_data, top_items=top_items, top_clients=top_clients, menu=db.execute("SELECT * FROM menu ORDER BY sort_weight DESC, category, name").fetchall(), users=db.execute("SELECT id, username, role, created_at FROM users ORDER BY id").fetchall(), zones=db.execute("SELECT * FROM zones").fetchall(), promos=db.execute("SELECT * FROM promocodes ORDER BY id DESC").fetchall(), avg_rating=avg_rating, reviews_count=reviews_count, recent_reviews=db.execute("SELECT * FROM orders WHERE rating > 0 ORDER BY id DESC LIMIT 5").fetchall(), shop_status=get_setting('shop_status'), banners=db.execute("SELECT * FROM banners ORDER BY id DESC").fetchall())

@app.route('/admin/users/add', methods=['POST'])
@login_required('admin')
def admin_user_add():
    username = request.form.get('username', '').strip(); password = request.form.get('password', ''); role = request.form.get('role')
    if username and password and role:
        db = get_db()
        try: db.execute("INSERT INTO users (username, password_hash, role, created_at) VALUES (?,?,?,?)", (username, generate_password_hash(password), role, datetime.now().strftime("%Y-%m-%d %H:%M:%S"))); db.commit()
        except sqlite3.IntegrityError: pass
    return redirect(url_for('admin_panel'))

@app.route('/admin/users/delete/<int:user_id>', methods=['POST'])
@login_required('admin')
def admin_user_delete(user_id):
    if user_id == session.get('user_id'): return "Вы не можете удалить свой аккаунт!", 400
    db = get_db(); db.execute("DELETE FROM users WHERE id=?", (user_id,)); db.commit(); return redirect(url_for('admin_panel'))

@app.route('/admin/export/orders')
@login_required('admin')
def export_orders():
    db = get_db(); orders = db.execute("SELECT * FROM orders ORDER BY id DESC").fetchall()
    wb = openpyxl.Workbook(); ws = wb.active; ws.title = "Заказы"
    ws.append(["ID", "Дата", "Клиент", "Адрес", "Тип", "Сумма", "Себестоимость", "Оплата", "Наличные", "Карта", "Сдача с", "Курьер", "Статус", "Промокод", "Оценка"])
    for o in orders: ws.append([o['id'], o['created_at'], o['phone'], o['address'], o['delivery_type'], o['total'], o['cost'], o['payment_method'], o['payment_cash'], o['payment_card'], o['change_from'], o['courier_name'], o['status'], o['promo_code'], o['rating']])
    output = io.BytesIO(); wb.save(output); output.seek(0)
    response = make_response(output.getvalue()); response.headers["Content-Disposition"] = "attachment; filename=orders.xlsx"; response.headers["Content-type"] = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"; return response

@app.route('/admin/export/clients')
@login_required('admin')
def export_clients():
    db = get_db(); clients = db.execute("SELECT * FROM clients ORDER BY total_spent DESC").fetchall()
    wb = openpyxl.Workbook(); ws = wb.active; ws.title = "Клиенты"
    ws.append(["Телефон", "Заказов", "Потрачено (LTV)", "Бонусы", "Уровень", "Последний заказ"])
    for c in clients: ws.append([c['phone'], c['orders_count'], c['total_spent'], c['bonuses'], c['level'], c['last_order_at']])
    output = io.BytesIO(); wb.save(output); output.seek(0)
    response = make_response(output.getvalue()); response.headers["Content-Disposition"] = "attachment; filename=clients.xlsx"; response.headers["Content-type"] = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"; return response

@app.route('/api/check_promo', methods=['POST'])
def check_promo():
    data = request.json or {}; code = data.get('code', '').strip().upper()
    promo = get_db().execute("SELECT * FROM promocodes WHERE code=? AND is_active=1", (code,)).fetchone()
    if promo: return jsonify({"success": True, "type": promo['discount_type'], "value": promo['discount_value']})
    return jsonify({"success": False, "error": "Промокод не найден"})

@app.route('/admin/promo/add', methods=['POST'])
@login_required('admin')
def admin_promo_add():
    code = request.form.get('code', '').strip().upper(); dtype = request.form.get('type'); val = request.form.get('value')
    if code and dtype and val:
        db = get_db()
        try: db.execute("INSERT INTO promocodes (code, discount_type, discount_value) VALUES (?,?,?)", (code, dtype, int(val))); db.commit()
        except sqlite3.IntegrityError: pass
    return redirect(url_for('admin_panel'))

@app.route('/admin/promo/delete/<int:promo_id>', methods=['POST'])
@login_required('admin')
def admin_promo_delete(promo_id):
    db = get_db(); db.execute("DELETE FROM promocodes WHERE id=?", (promo_id,)); db.commit(); return redirect(url_for('admin_panel'))

@app.route('/admin/menu/add', methods=['POST'])
@login_required('admin')
def admin_menu_add():
    name, price, category = request.form.get('name'), request.form.get('price'), request.form.get('category')
    file = request.files.get('image'); filename = ''
    if file and file.filename and allowed_file(file.filename):
        filename = str(uuid.uuid4()) + '.' + file.filename.rsplit('.', 1)[1].lower(); file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
    if name and price and category:
        db = get_db(); db.execute("INSERT INTO menu (name, price, category, image, composition, modifiers, sort_weight) VALUES (?,?,?,?,?,?,?)", (name, int(price), category, filename, request.form.get('composition', ''), request.form.get('modifiers', ''), int(request.form.get('sort_weight', 0)))); db.commit()
    return redirect(url_for('admin_panel'))

@app.route('/admin/menu/edit/<int:menu_id>', methods=['GET', 'POST'])
@login_required('admin')
def admin_menu_edit(menu_id):
    db = get_db()
    if request.method == 'POST':
        name, price, category = request.form.get('name'), request.form.get('price'), request.form.get('category')
        file = request.files.get('image')
        if file and file.filename and allowed_file(file.filename):
            filename = str(uuid.uuid4()) + '.' + file.filename.rsplit('.', 1)[1].lower(); file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            db.execute("UPDATE menu SET name=?, price=?, category=?, composition=?, modifiers=?, image=?, sort_weight=? WHERE id=?", (name, int(price), category, request.form.get('composition', ''), request.form.get('modifiers', ''), filename, int(request.form.get('sort_weight', 0)), menu_id))
        else: db.execute("UPDATE menu SET name=?, price=?, category=?, composition=?, modifiers=?, sort_weight=? WHERE id=?", (name, int(price), category, request.form.get('composition', ''), request.form.get('modifiers', ''), int(request.form.get('sort_weight', 0)), menu_id))
        db.execute("DELETE FROM recipes WHERE menu_id=?", (menu_id,))
        for key, val in request.form.items():
            if key.startswith('ing_') and val.strip(): db.execute("INSERT INTO recipes (menu_id, ingredient_id, amount) VALUES (?,?,?)", (menu_id, key.split('_')[1], float(val)))
        db.commit(); return redirect(url_for('admin_panel'))
    return render_template('edit_menu.html', item=db.execute("SELECT * FROM menu WHERE id=?", (menu_id,)).fetchone(), ingredients=db.execute("SELECT * FROM ingredients ORDER BY name").fetchall(), recipe={r['ingredient_id']: r['amount'] for r in db.execute("SELECT * FROM recipes WHERE menu_id=?", (menu_id,)).fetchall()})

@app.route('/admin/menu/toggle/<int:menu_id>', methods=['POST'])
@login_required('admin')
def admin_menu_toggle(menu_id):
    db = get_db(); db.execute("UPDATE menu SET available = 1 - available WHERE id=?", (menu_id,)); db.commit(); return redirect(url_for('admin_panel'))

@app.route('/admin/menu/stop/<int:menu_id>', methods=['POST'])
@login_required('admin')
def admin_menu_stop(menu_id):
    db = get_db(); db.execute("UPDATE menu SET stop_list = 1 - stop_list WHERE id=?", (menu_id,)); db.commit(); return redirect(url_for('admin_panel'))

@app.route('/admin/menu/delete/<int:menu_id>', methods=['POST'])
@login_required('admin')
def admin_menu_delete(menu_id):
    db = get_db(); db.execute("DELETE FROM menu WHERE id=?", (menu_id,)); db.commit(); return redirect(url_for('admin_panel'))

@app.route('/admin/menu/clear', methods=['POST'])
@login_required('admin')
def admin_menu_clear():
    db = get_db(); db.execute("DELETE FROM menu"); db.commit(); return redirect(url_for('admin_panel'))

@app.route('/rate/<int:order_id>', methods=['GET', 'POST'])
def rate_order(order_id):
    db = get_db(); order = db.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
    if not order: abort(404)
    if request.method == 'POST':
        if order['rating'] > 0: return "<h1 style='text-align:center; color:#ff9f0a; font-family:sans-serif; margin-top:50px'>Вы уже оставили отзыв!</h1>"
        rating_val = min(5, max(1, int(request.form.get('rating', 5))))
        db.execute("UPDATE orders SET rating=?, review_text=? WHERE id=?", (rating_val, request.form.get('review_text', '').strip(), order_id)); db.commit()
        return "<h1 style='text-align:center; color:#30d158; font-family:sans-serif; margin-top:50px'>Спасибо за отзыв!</h1>"
    return render_template('rate.html', order=order)

@app.route('/site')
def public_site():
    db = get_db()
    return render_template('public_site.html', menu=db.execute("SELECT * FROM menu WHERE available=1 AND stop_list=0 ORDER BY sort_weight DESC, category, name").fetchall(), categories=db.execute("SELECT DISTINCT category FROM menu WHERE available=1 AND stop_list=0 ORDER BY category").fetchall(), shop_open=is_shop_open(), banners=db.execute("SELECT * FROM banners ORDER BY id DESC").fetchall())

@app.route('/api/public_order', methods=['POST'])
def public_order():
    if not is_shop_open(): return jsonify({"error": "Мы работаем с 10:00 до 21:30."}), 400
    data = request.json or {}; raw_items = data.get('items', [])
    if not raw_items: return jsonify({"error": "Пустой заказ"}), 400
    items, val_err = validate_and_prepare_items(raw_items, allow_stop_list=False)
    if val_err: return jsonify({"error": val_err}), 400
    db = get_db(); err, total_cost = deduct_ingredients(items)
    if err: db.rollback(); return jsonify({"error": err}), 400
    shift = get_open_shift(); shift_id = shift['id'] if shift else None
    subtotal = sum(i['price'] * i['qty'] for i in items)
    promo_code = data.get('promo_code', '').strip().upper(); promo_discount = 0
    if promo_code:
        promo = db.execute("SELECT * FROM promocodes WHERE code=? AND is_active=1", (promo_code,)).fetchone()
        if promo: promo_discount = (subtotal * promo['discount_value']) // 100 if promo['discount_type'] == 'percent' else promo['discount_value']
    total = max(0, subtotal - promo_discount)
    phone = data.get('phone', '').strip(); address = data.get('address', '').strip()
    pay_method = data.get('payment_method', 'не указан'); change_from = int(data.get('change_from', 0) or 0)
    delivery_type = data.get('delivery_type', 'доставка')
    if delivery_type == 'самовывоз': address = 'Самовывоз'
    pay_cash, pay_card = split_payment_amounts(pay_method, total, total if pay_method == 'наличные' else 0)
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cur = db.execute("INSERT INTO orders (created_at, status, total, cost, address, phone, comment, shift_id, payment_method, payment_cash, payment_card, change_from, delivery_type, promo_code, source) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (now_str, 'new', total, total_cost, address, phone, data.get('comment', ''), shift_id, pay_method, pay_cash, pay_card, change_from, delivery_type, promo_code, 'Сайт'))
    order_id = cur.lastrowid
    for i in items: db.execute("INSERT INTO order_items (order_id, menu_id, name, price, qty, modifiers) VALUES (?,?,?,?,?,?)", (order_id, i['id'], i['name'], i['price'], i['qty'], i['mods']))
    if phone:
        client = db.execute("SELECT * FROM clients WHERE phone=?", (phone,)).fetchone()
        new_total_spent = (client['total_spent'] if client else 0) + total
        new_level = 'gold' if new_total_spent >= 30000 else ('silver' if new_total_spent >= 10000 else 'bronze')
        cashback_rate = 0.10 if new_level == 'gold' else (0.07 if new_level == 'silver' else 0.05)
        earned_bonus = int(total * cashback_rate)
        db.execute("INSERT INTO clients (phone, total_spent, orders_count, last_order_at, level, bonuses) VALUES (?,?,?,?,?,?) ON CONFLICT(phone) DO UPDATE SET total_spent=total_spent+?, orders_count=orders_count+1, last_order_at=?, level=?, bonuses=bonuses+?", (phone, total, 1, now_str, new_level, earned_bonus, total, now_str, new_level, earned_bonus))
    db.commit(); send_tg_async(f"🌐 <b>НОВЫЙ ЗАКАЗ С САЙТА #{order_id}</b>\n💰 Сумма: <b>{total} ₽</b> ({pay_method})\n📞 Тел: {phone}\n📍 Адрес: {address}")
    return jsonify({"success": True, "order_id": order_id})

@app.route('/api/site/client/<phone>')
def site_client(phone):
    order = get_db().execute("SELECT * FROM orders WHERE phone=? ORDER BY id DESC LIMIT 1", (phone,)).fetchone()
    if order: return jsonify({"success": True, "address": order['address'], "last_order": [dict(i) for i in get_db().execute("SELECT * FROM order_items WHERE order_id=?", (order['id'],)).fetchall()]})
    return jsonify({"success": False})

@app.route('/api/client/<phone>')
@login_required('admin', 'cashier')
def api_client(phone):
    client = get_db().execute("SELECT * FROM clients WHERE phone=?", (phone,)).fetchone()
    if client: return jsonify({"success": True, "bonuses": client['bonuses'], "level": client['level']})
    return jsonify({"success": False})

@app.route('/api/create_order', methods=['POST'])
@login_required('admin', 'cashier')
def create_order():
    if not is_shop_open(): return jsonify({"error": "Прием заказов приостановлен (10:00-21:30)."}), 400
    data = request.json or {}; raw_items = data.get('items', [])
    if not raw_items: return jsonify({"error": "Пустой заказ"}), 400
    shift = get_open_shift()
    if not shift: return jsonify({"error": "Смена не открыта"}), 400
    items, val_err = validate_and_prepare_items(raw_items, allow_stop_list=False)
    if val_err: return jsonify({"error": val_err}), 400
    db = get_db(); err, total_cost = deduct_ingredients(items)
    if err: db.rollback(); return jsonify({"error": err}), 400
    phone = data.get('phone', '').strip(); address = data.get('address', '').strip()
    delivery_type = data.get('delivery_type', 'доставка')
    if delivery_type == 'самовывоз': address = 'Самовывоз'
    zone_str = data.get('zone', '') if delivery_type == 'доставка' else ''
    subtotal = sum(i['price'] * i['qty'] for i in items)
    discount_val = max(0, int(data.get('discount', 0) or 0)); discount_type = data.get('discount_type', 'rub')
    manual_discount = (subtotal * discount_val // 100) if discount_type == 'percent' else discount_val
    promo_code = data.get('promo_code', '').strip().upper(); promo_discount = 0
    if promo_code:
        promo = db.execute("SELECT * FROM promocodes WHERE code=? AND is_active=1", (promo_code,)).fetchone()
        if promo: promo_discount = (subtotal * promo['discount_value']) // 100 if promo['discount_type'] == 'percent' else promo['discount_value']
    client = db.execute("SELECT * FROM clients WHERE phone=?", (phone,)).fetchone() if phone else None
    client_level = client['level'] if client else 'bronze'
    delivery_price = parse_zone_price(zone_str, delivery_type, client_level)
    total = max(0, subtotal - manual_discount - promo_discount) + delivery_price
    use_bonus = max(0, int(data.get('use_bonus', 0) or 0))
    actual_bonus = 0
    if use_bonus > 0 and client:
        actual_bonus = min(use_bonus, client['bonuses'], total)
        total = max(0, total - actual_bonus)
        db.execute("UPDATE clients SET bonuses = bonuses - ? WHERE phone=?", (actual_bonus, phone))
    payment_method = data.get('payment_method', 'не указан')
    pay_cash, pay_card = split_payment_amounts(payment_method, total, data.get('pay_cash', 0))
    change_from = max(0, int(data.get('change_from', 0) or 0))
    scheduled_time = data.get('scheduled_time', '').strip() or None
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cur = db.execute('''
        INSERT INTO orders (
            created_at, status, total, cost, address, phone, comment, shift_id, cashier_id, source,
            payment_method, payment_cash, payment_card, change_from, delivery_type, delivery_zone, delivery_price,
            used_bonus, scheduled_time, discount, discount_type, promo_code
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    ''', (now_str, 'new', total, total_cost, address, phone, data.get('comment', ''), shift['id'], session['user_id'], 'Касса', payment_method, pay_cash, pay_card, change_from, delivery_type, zone_str, delivery_price, actual_bonus, scheduled_time, discount_val, discount_type, promo_code))
    order_id = cur.lastrowid
    for i in items: db.execute("INSERT INTO order_items (order_id, menu_id, name, price, qty, modifiers) VALUES (?,?,?,?,?,?)", (order_id, i['id'], i['name'], i['price'], i['qty'], i['mods']))
    if phone:
        new_total_spent = (client['total_spent'] if client else 0) + total
        new_level = 'gold' if new_total_spent >= 30000 else ('silver' if new_total_spent >= 10000 else 'bronze')
        cashback_rate = 0.10 if new_level == 'gold' else (0.07 if new_level == 'silver' else 0.05)
        earned_bonus = int(total * cashback_rate)
        db.execute("INSERT INTO clients (phone, total_spent, orders_count, last_order_at, level, bonuses) VALUES (?,?,?,?,?,?) ON CONFLICT(phone) DO UPDATE SET total_spent=total_spent+?, orders_count=orders_count+1, last_order_at=?, level=?, bonuses=bonuses+?", (phone, total, 1, now_str, new_level, earned_bonus, total, now_str, new_level, earned_bonus))
    db.commit(); send_tg_async(f"🖥️ <b>ЗАКАЗ С КАССЫ #{order_id}</b>\n💰 Сумма: <b>{total} ₽</b> ({payment_method})\n📞 Тел: {phone or '—'}\n📍 Адрес: {address or '—'}")
    return jsonify({"success": True, "order_id": order_id, "total": total})

@app.route('/api/orders')
@login_required()
def api_orders():
    status = request.args.get('status'); db = get_db()
    if status:
        if status == 'active': rows = db.execute("SELECT * FROM orders WHERE status IN ('new', 'cooking') ORDER BY id").fetchall()
        elif status == 'all_active': rows = db.execute("SELECT * FROM orders WHERE status IN ('new', 'cooking', 'ready', 'delivering') ORDER BY id").fetchall()
        else: rows = db.execute("SELECT * FROM orders WHERE status=? ORDER BY id", (status,)).fetchall()
    else: rows = db.execute("SELECT * FROM orders ORDER BY id DESC").fetchall()
    return jsonify([dict(r) | {"items": [dict(i) for i in db.execute("SELECT * FROM order_items WHERE order_id=?", (r['id'],)).fetchall()]} for r in rows])

@app.route('/api/courier/stats')
@login_required('courier', 'admin')
def api_courier_stats():
    db = get_db(); today = datetime.now().strftime("%Y-%m-%d"); name = session['username']
    row = db.execute("SELECT COUNT(*) cnt, COALESCE(SUM(payment_cash),0) cash_on_hand FROM orders WHERE date(created_at)=? AND courier_name=? AND status IN ('delivering', 'done')", (today, name)).fetchone()
    return jsonify({"courier": name, "delivered_count": row['cnt'], "cash_on_hand": row['cash_on_hand']})

@app.route('/api/set_status/<int:order_id>', methods=['POST'])
@login_required()
def set_status(order_id):
    data = request.json or {}; new_status = data.get('status'); db = get_db()
    order = db.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
    if not order: return jsonify({"error": "Заказ не найден"}), 404
    if order['status'] == new_status: return jsonify({"success": True})
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        if new_status == 'cancelled' and order['status'] != 'cancelled':
            for i in db.execute("SELECT menu_id, qty FROM order_items WHERE order_id=?", (order_id,)).fetchall():
                if i['menu_id']:
                    for r in db.execute("SELECT ingredient_id, amount FROM recipes WHERE menu_id=?", (i['menu_id'],)).fetchall():
                        db.execute("UPDATE ingredients SET stock = ROUND(stock + ?, 4) WHERE id=?", (r['amount'] * i['qty'], r['ingredient_id']))
            if order['phone']:
                client = db.execute("SELECT * FROM clients WHERE phone=?", (order['phone'],)).fetchone()
                if client:
                    rate = 0.10 if client['level'] == 'gold' else (0.07 if client['level'] == 'silver' else 0.05)
                    earned = int(order['total'] * rate)
                    refund_bonus = dict(order).get('used_bonus') or 0
                    db.execute("UPDATE clients SET total_spent = MAX(0, total_spent - ?), orders_count = MAX(0, orders_count - 1), bonuses = MAX(0, bonuses - ? + ?) WHERE phone=?", (order['total'], earned, refund_bonus, order['phone']))
        if new_status == 'cooking':
            db.execute("UPDATE orders SET status=?, cook_start_time=? WHERE id=?", (new_status, now_str, order_id))
        elif new_status == 'ready':
            db.execute("UPDATE orders SET status=?, cook_end_time=? WHERE id=?", (new_status, now_str, order_id))
        elif new_status == 'delivering':
            c_name = data.get('courier_name') or session.get('username', '')
            db.execute("UPDATE orders SET status=?, courier_name=? WHERE id=?", (new_status, c_name, order_id))
        else:
            db.execute("UPDATE orders SET status=? WHERE id=?", (new_status, order_id))
        db.commit()
        return jsonify({"success": True})
    except Exception as e:
        db.rollback(); return jsonify({"error": str(e)}), 500


@app.route('/api/cash_op', methods=['POST'])
@login_required('admin', 'cashier')
def cash_op():
    data = request.json or {}
    op_type = data.get('op_type') # 'float_in' (размен) или 'collection' (инкассация)
    amount = int(data.get('amount', 0))
    comment = data.get('comment', '').strip()
    shift = get_open_shift()
    if not shift or amount <= 0: return jsonify({"error": "Смена не открыта или сумма некорректна"}), 400
    db = get_db()
    db.execute("INSERT INTO cash_operations (shift_id, op_type, amount, comment, created_at, username) VALUES (?,?,?,?,?,?)",
               (shift['id'], op_type, amount, comment, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), session['username']))
    db.commit()
    return jsonify({"success": True})


@app.route('/autopilot')
@login_required('admin')
def autopilot_panel():
    db = get_db()
    # 1. Анализ меню (Матрица маржинальности и популярности + стандарт 8 кусочков)
    menu_rows = db.execute("SELECT * FROM menu WHERE available=1 ORDER BY category, name").fetchall()
    sales_rows = db.execute('''
        SELECT oi.name, SUM(oi.qty) as sold_qty, SUM(oi.price * oi.qty) as sold_rev
        FROM order_items oi JOIN orders o ON oi.order_id = o.id
        WHERE o.status != 'cancelled'
        GROUP BY oi.name
    ''').fetchall()
    sales_map = {r['name']: {'qty': r['sold_qty'] or 0, 'rev': r['sold_rev'] or 0} for r in sales_rows}

    menu_matrix = []
    total_qty_all = sum(v['qty'] for v in sales_map.values())
    avg_qty = (total_qty_all / len(menu_rows)) if menu_rows else 1

    for m in menu_rows:
        recs = db.execute('''
            SELECT r.amount, ing.cost_price, COALESCE(ing.waste_pct, 0) as waste_pct
            FROM recipes r JOIN ingredients ing ON r.ingredient_id = ing.id
            WHERE r.menu_id=?
        ''', (m['id'],)).fetchall()
        weight = sum(r['amount'] for r in recs)
        cost = 0.0
        for r in recs:
            w = min(95.0, max(0.0, float(r['waste_pct'] or 0)))
            factor = 1.0 / (1.0 - w / 100.0) if w > 0 else 1.0
            cost += r['amount'] * factor * r['cost_price']
        margin_rub = m['price'] - cost
        fc_pct = round((cost / m['price'] * 100), 1) if m['price'] > 0 else 0
        sold = sales_map.get(m['name'], {}).get('qty', 0)

        is_roll = 'ролл' in (m['category'] or '').lower() or 'ролл' in m['name'].lower()
        piece_weight = round(weight / 8.0, 1) if (is_roll and weight > 0) else 0

        if sold >= avg_qty and fc_pct <= 33:
            quadrant = "⭐ Звезда (Хит + Выгода)"
            q_color = "#10b981"
            advice = "Держать в топе витрины, не менять рецептуру"
        elif sold >= avg_qty and fc_pct > 33:
            quadrant = "🐄 Дойная корова (Хит, низкая маржа)"
            q_color = "#3b82f6"
            advice = "Поднять цену на +30..50 ₽ или проверить граммовку"
        elif sold < avg_qty and fc_pct <= 33:
            quadrant = "🧩 Загадка (Сверхприбыльное)"
            q_color = "#f59e0b"
            advice = "Добавить в Сеты и предлагать на кассе (Upsell)"
        else:
            quadrant = "🐕 Кандидат на замену"
            q_color = "#ef4444"
            advice = "Переработать ТТК или вывести из меню"

        menu_matrix.append({
            'id': m['id'], 'name': m['name'], 'category': m['category'],
            'price': m['price'], 'cost': round(cost, 1), 'margin': round(margin_rub, 1),
            'fc_pct': fc_pct, 'weight': round(weight), 'piece_weight': piece_weight,
            'sold': sold, 'quadrant': quadrant, 'q_color': q_color, 'advice': advice
        })

    # 2. Предиктивный план заготовок на смену (с учетом коэффициента дня недели)
    weekday = datetime.now().weekday() # 4=Пт, 5=Сб, 6=Вс
    day_names = ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница 🔥', 'Суббота 🔥', 'Воскресенье']
    day_mult = 1.45 if weekday in (4, 5) else (1.2 if weekday == 6 else 1.0)

    # Считаем средний дневной расход каждого ингредиента за последние 14 дней (или берем базовую норму)
    ings = db.execute("SELECT * FROM ingredients ORDER BY is_prep DESC, name").fetchall()
    prep_plan = []
    purchase_list = []

    for ing in ings:
        used_row = db.execute('''
            SELECT SUM(oi.qty * r.amount) as total_used, COUNT(DISTINCT date(o.created_at)) as active_days
            FROM order_items oi
            JOIN orders o ON oi.order_id = o.id
            JOIN recipes r ON r.menu_id = oi.menu_id
            WHERE r.ingredient_id = ? AND o.status != 'cancelled'
        ''', (ing['id'],)).fetchone()

        days_cnt = max(1, used_row['active_days'] or 1)
        avg_daily = (used_row['total_used'] or 0) / days_cnt
        if avg_daily <= 0:
            avg_daily = float(ing['prep_yield'] or 1000) * 0.5 if ing['is_prep'] else 500.0

        recommended_today = round(avg_daily * day_mult, 1)
        deficit = round(max(0.0, recommended_today - ing['stock']), 1)

        prep_plan.append({
            'id': ing['id'], 'name': ing['name'], 'unit': ing['unit'],
            'is_prep': ing['is_prep'], 'stock': round(ing['stock'], 1),
            'recommended': recommended_today, 'to_make': deficit
        })
        if deficit > 0 and not ing['is_prep']:
            purchase_list.append(f"• {ing['name']}: заказать Минимум {round(deficit * 2, 1)} {ing['unit']} (остаток: {round(ing['stock'], 1)} {ing['unit']})")

    return render_template('autopilot.html',
                           menu_matrix=menu_matrix,
                           prep_plan=prep_plan,
                           purchase_text="\n".join(purchase_list) if purchase_list else "Все сырье в достатке!",
                           today_name=day_names[weekday],
                           day_mult=day_mult)

@app.route('/admin/warehouse/butcher', methods=['POST'])
@login_required('admin')
def admin_warehouse_butcher():
    db = get_db()
    raw_id = int(request.form.get('raw_id') or 0)
    raw_weight = float(request.form.get('raw_weight') or 0)
    raw_ing = db.execute("SELECT * FROM ingredients WHERE id=?", (raw_id,)).fetchone()
    if not raw_ing or raw_weight <= 0:
        return redirect(url_for('warehouse_panel'))

    out1_id = int(request.form.get('out1_id') or 0)
    out1_w = float(request.form.get('out1_weight') or 0)
    out2_id = int(request.form.get('out2_id') or 0)
    out2_w = float(request.form.get('out2_weight') or 0)

    total_usable = out1_w + out2_w
    if total_usable <= 0:
        return redirect(url_for('warehouse_panel'))

    now_str = datetime.now().strftime("%Y-%m-%d %H:%M")
    total_batch_cost = raw_weight * float(raw_ing['cost_price'] or 0)
    actual_waste_pct = round(max(0.0, (raw_weight - total_usable) / raw_weight * 100.0), 1)

    # Списываем тушку Брутто
    db.execute("UPDATE ingredients SET stock = ROUND(stock - ?, 4), waste_pct = ? WHERE id=?", (raw_weight, actual_waste_pct, raw_id))
    db.execute("INSERT INTO stock_logs (created_at, ingredient_id, ing_name, change_amount, op_type, reason, cost_impact, username) VALUES (?,?,?,?,?,?,?,?)",
               (now_str, raw_id, raw_ing['name'], -raw_weight, 'разделка', f"Разделка тушки (отход {actual_waste_pct}%)", -round(total_batch_cost, 1), session['username']))

    # Распределяем себестоимость: основному филе 85% веса стоимости, обрези — 15% (или пропорционально весу)
    eff_cost_per_unit = round(total_batch_cost / total_usable, 4)

    for oid, ow in [(out1_id, out1_w), (out2_id, out2_w)]:
        if oid > 0 and ow > 0:
            oing = db.execute("SELECT * FROM ingredients WHERE id=?", (oid,)).fetchone()
            if oing:
                db.execute("UPDATE ingredients SET stock = ROUND(stock + ?, 4), cost_price = ? WHERE id=?", (ow, eff_cost_per_unit, oid))
                db.execute("INSERT INTO stock_logs (created_at, ingredient_id, ing_name, change_amount, op_type, reason, cost_impact, username) VALUES (?,?,?,?,?,?,?,?)",
                           (now_str, oid, oing['name'], ow, 'выход разделки', f"Из {raw_ing['name']} ({raw_weight} ед.)", round(ow * eff_cost_per_unit, 1), session['username']))
    db.commit()
    return redirect(url_for('warehouse_panel'))

@app.route('/board')
def public_board():
    return render_template('board.html')

@app.route('/api/kitchen_load')
def api_kitchen_load():
    db = get_db()
    active_cnt = db.execute("SELECT COUNT(*) FROM orders WHERE status IN ('new', 'cooking')").fetchone()[0]
    ready_orders = [dict(r) for r in db.execute("SELECT id, delivery_type FROM orders WHERE status='ready' ORDER BY id DESC LIMIT 12").fetchall()]
    cooking_orders = [dict(r) for r in db.execute("SELECT id, delivery_type FROM orders WHERE status IN ('new', 'cooking') ORDER BY id DESC LIMIT 12").fetchall()]
    if active_cnt <= 3:
        level, est_min, color = "🟢 Кухня свободна", 35, "#10b981"
    elif active_cnt <= 7:
        level, est_min, color = "🟡 Средняя загрузка", 55, "#f59e0b"
    else:
        level, est_min, color = "🔴 ПИК / ЗАПАРА", 75, "#ef4444"
    return jsonify({
        "active_count": active_cnt,
        "level": level,
        "est_minutes": est_min,
        "color": color,
        "ready": ready_orders,
        "cooking": cooking_orders
    })


@app.route('/api/delivery_route')
@login_required('admin', 'courier', 'cashier')
def api_delivery_route():
    db = get_db()
    orders = db.execute("SELECT id, address, total, phone FROM orders WHERE status IN ('ready', 'delivering') AND address != 'Самовывоз'").fetchall()
    # Эмуляция гео-точек для построения маршрута по Инте
    points = []
    for o in orders:
        points.append({
            "id": o['id'],
            "address": o['address'],
            "phone": o['phone'],
            "total": o['total'],
            "lat": 66.0350 + (o['id'] % 10) * 0.005,
            "lng": 60.1450 + (o['id'] % 7) * 0.008
        })
    return jsonify(points)

if __name__ == '__main__':
    init_db()
    print("="*55)
    print("🚀 СИСТЕМА КРЕВЕТКА PRO ЗАПУЩЕНА!")
    print("="*55)
    app.run(host='0.0.0.0', port=5000, debug=True)
