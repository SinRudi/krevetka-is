#!/usr/bin/env python3
import sqlite3
import time
import os

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sushi.db')
last_printed_order_id = 0

print("🖨️ АГЕНТ ПЕЧАТИ ESC/POS ЗАПУЩЕН. Ожидание новых заказов...")
print("(Для выхода нажмите Ctrl+C)")

while True:
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        orders = conn.execute("SELECT * FROM orders WHERE id > ? AND status='new' ORDER BY id", (last_printed_order_id,)).fetchall()
        for o in orders:
            items = conn.execute("SELECT * FROM order_items WHERE order_id=?", (o['id'],)).fetchall()
            
            print("\n" + "="*40)
            print(f"       НОВЫЙ ЗАКАЗ #{o['id']}")
            print("="*40)
            print(f"Время: {o['created_at']}")
            print(f"Тип: {o['delivery_type']}")
            if o['address']: print(f"Адрес: {o['address']}")
            print("-"*40)
            for i in items:
                print(f"{i['name']} x{i['qty']} = {i['price']*i['qty']} руб.")
                if i['modifiers']: print(f"   ↳ {i['modifiers']}")
            print("-"*40)
            print(f"ИТОГО: {o['total']} руб. ({o['payment_method']})")
            if o['comment']: print(f"КОММ: {o['comment']}")
            print("="*40 + "\n")
            
            last_printed_order_id = o['id']
        conn.close()
    except Exception as e:
        pass
    time.sleep(3)
